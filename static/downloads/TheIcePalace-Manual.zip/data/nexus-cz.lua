-- Campaign screen layout

function start()
  Add(4, 7.5, Peg.Level, 0, "missions/basic1", "Vchod")
  Add(8, 7.5, Peg.Level, 1, "missions/basic2", "Bariéra")
  Add(12, 7.5, Peg.Level, 2, "missions/basic3", "Klíč")
  Add(16, 7.5, Peg.Level, 3, "missions/basic4", "Výstup")
  Add(6, 11, Peg.Level, 3, "missions/basic5", "Truhly")
  Add(10, 11, Peg.Page, 5, "wood", "Les")
  Add(14, 11, Peg.Level, 5, "missions/basic6", "Cíl")

  Add(4, 4, Peg.Back)
  Add(8, 4, Peg.Book, 0, "primer", "Průvodce")
  Add(12, 4, Peg.Book, 0, "credits-small", "Titulky")

  Add(16, 4, Peg.Page, #CustomMissions() == 0 and 14 or 0, "skip", "Levely")

  return { bg = {0.1, 0.04, 0.45} }
end

function wood()
  Add(8, 3, Peg.Level, 5, "missions/wood1", "Cesta")
  Add(12, 3, Peg.Level, 6, "missions/wood2", "Reset")
  Add(16, 3, Peg.Level, 7, "missions/wood3", "Výstupky")
  Add(6, 6, Peg.Level, 7, "missions/wood4", "Past")
  Add(10, 6, Peg.Level, 8, "missions/wood5", "Bezpečno")
  Add(14, 6, Peg.Level, 9, "missions/wood6", "Jámy")
  Add(4, 9, Peg.Level, 10, "missions/wood7", "Nepříjemná")
  Add(8, 9, Peg.Level, 11, "missions/wood8", "Situace")
  Add(12, 9, Peg.Level, 12, "missions/wood9", "Smyčka")
  Add(16, 9, Peg.Level, 13, "missions/wood10", "Uzel")
  Add(6, 12, Peg.Page, 14, "sewer", "Stoka")
  Add(10, 12, Peg.Level, 15, "missions/wood11", "Perspektiva")
  Add(14, 12, Peg.Level, 16, "missions/wood12", "Bezpečnější")

  Add(4, 3, Peg.Back)

  return { bg = {0.2, 0.4, 0.2} }
end

function sewer()
  Add(8, 6, Peg.Level, 14, "missions/sewer1", "Zaplavení")
  Add(12, 6, Peg.Level, 15, "missions/sewer2", "Vypustit")
  Add(6, 9, Peg.Level, 16, "missions/sewer3", "Nádrž")
  Add(10, 9, Peg.Level, 17, "missions/sewer4", "Opakovat")
  Add(14, 9, Peg.Level, 18, "missions/sewer5", "Petlice")
  Add(4, 12, Peg.Level, 19, "missions/sewer6", "Vír")
  Add(8, 12, Peg.Page, 20, "castle", "Žalář")
  Add(12, 12, Peg.Level, 21, "missions/sewer7", "Prohodit")
  Add(16, 12, Peg.Level, 22, "missions/sewer8", "Náhled")

  Add(10, 3, Peg.Back)

  return { bg = {0.15, 0.35, 0.5} }
end

function castle()
  Add(6, 5.5, Peg.Level, 20, "missions/basement1", "Zelený")
  Add(9, 4.5, Peg.Level, 21, "missions/basement2", "Uschovat")
  Add(12, 3.5, Peg.Level, 22, "missions/basement3", "Hromada")
  Add(6, 9.5, Peg.Level, 23, "missions/basement4", "Dosah")
  Add(9, 8.5, Peg.Level, 24, "missions/basement5", "Vězení")
  Add(12, 7.5, Peg.Level, 25, "missions/basement6", "Prázdný")
  Add(15, 6.5, Peg.Level, 26, "missions/basement7", "Nejbezpečnější")
  Add(9, 12.5, Peg.Level, 27, "missions/basement8", "Stavidlo")
  Add(12, 11.5, Peg.Page, 28, "villa", "Ruiny")
  Add(15, 10.5, Peg.Level, 29, "missions/basement9", "Půda")
  Add(18, 9.5, Peg.Level, 30, "missions/basement10", "Překážka")

  Add(3, 6.5, Peg.Back)

  return { bg = {0.3, 0.15, 0.25} }
end

function villa()
  Add(6, 3, Peg.Level, 28, "missions/garden1", "Propadání")
  Add(9, 3, Peg.Level, 29, "missions/garden2", "Most")
  Add(6, 6, Peg.Level, 30, "missions/garden3", "Kyselina")
  Add(9, 6, Peg.Level, 31, "missions/garden4", "Překážka")
  Add(12, 6, Peg.Level, 32, "missions/garden5", "Feedback")
  Add(9, 9, Peg.Level, 33, "missions/garden6", "Lázeň")
  Add(12, 9, Peg.Level, 34, "missions/garden7", "vložit")
  Add(15, 9, Peg.Level, 35, "missions/garden8", "Sloup")
  Add(12, 12, Peg.Page, 36, "temple", "Chrám")
  Add(15, 12, Peg.Level, 37, "missions/garden9", "Šlamastyka")
  Add(18, 12, Peg.Level, 38, "missions/garden10", "západka")

  Add(3, 3, Peg.Back)

  return { bg = {0.7, 0.65, 0.75} }
end

function temple()
  Add(10, 3, Peg.Level, 36, "missions/temple1", "Magické zřídlo")
  Add(14, 3, Peg.Level, 37, "missions/temple2", "Pokračovat")
  Add(4, 6, Peg.Level, 38, "missions/temple3", "Stálost")
  Add(8, 6, Peg.Level, 39, "missions/temple4", "Restrukturalizovat")
  Add(12, 6, Peg.Level, 40, "missions/temple5", "Láhev")
  Add(16, 6, Peg.Level, 41, "missions/temple6", "Postavit")
  Add(6, 9, Peg.Level, 42, "missions/temple7", "Vnitřní")
  Add(10, 9, Peg.Level, 43, "missions/temple8", "Splést")
  Add(14, 9, Peg.Level, 44, "missions/temple9", "Sevřít")
  Add(4, 12, Peg.Level, 45, "missions/temple10", "Překročení")
  Add(8, 12, Peg.Page, 48, "dark", "Nicota")
  Add(12, 12, Peg.Level, 49, "missions/temple11", "Voděodolný")
  Add(16, 12, Peg.Level, 50, "missions/temple12", "Puchýř")

  Add(6, 3, Peg.Back)

  return { bg = {0.65, 0.45, 0.1} }
end

function dark(complete)
  local x = 0.86602540378;
  Add(10, 3.5, Peg.Level, 48, "missions/dark1", "Chňapnout")
  Add(10 + 4 * x, 5.5, Peg.Level, 50, "missions/dark2", "Špacírovat")
  Add(10 + 4 * x, 9.5, Peg.Level, 52, "missions/dark3", "Náklad")
  Add(10, 11.5, Peg.Level, 54, "missions/dark4", "Oltář")
  Add(10 - 4 * x, 9.5, Peg.Level, 56, "missions/dark5", "Vystupňovat")
  Add(10 - 4 * x, 5.5, Peg.Level, 58, "missions/dark6", "Trilema")

  if complete then
    Add(17.5, 7.5, Peg.Book, 0, "credits-full", "Konec")
  end
  Add(10, 7.5, Peg.Back)

  return { bg = {0.1, 0.0, 0.1} }
end

function skip(complete)
  Add(10, 11, Peg.Back)
  Add(4, 10, Peg.Page, 5, "wood", "Les")
  Add(5, 6.5, Peg.Page, 14, "sewer", "Stoka")
  Add(8, 4, Peg.Page, 20, "castle", "Žalář")
  Add(12, 4, Peg.Page, 28, "villa", "Ruiny")
  Add(15, 6.5, Peg.Page, 36, "temple", "Chrám")
  Add(16, 10, Peg.Page, 48, "dark", "Nicota")

  Add(6, 13, Peg.Hub, 28, "dlc", "Ooblekový hlavolam")
  Add(14, 13, Peg.Hub, 28, "dlc2", "Poslední tapisérie")

  if #CustomMissions() > 0 then
    Add(10, 7.5, Peg.Hub, 0, "custom", "Custom")
  end
  
  Add(17, 3, Peg.Hub, complete and 0 or 999, "TheIcePalace", "The Ice Palace")

  return { bg = {0.4, 0.0, 0.0} }
end

