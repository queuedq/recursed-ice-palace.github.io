-- Campaign screen layout

function start()
  Add(4, 7.5, Peg.Level, 0, "missions/basic1", "Начало")
  Add(8, 7.5, Peg.Level, 1, "missions/basic2", "Барьер")
  Add(12, 7.5, Peg.Level, 2, "missions/basic3", "Ключ")
  Add(16, 7.5, Peg.Level, 3, "missions/basic4", "Подъём")
  Add(6, 11, Peg.Level, 3, "missions/basic5", "Сундуки")
  Add(10, 11, Peg.Page, 5, "wood", "Лес")
  Add(14, 11, Peg.Level, 5, "missions/basic6", "Цель")

  Add(4, 4, Peg.Back)
  Add(8, 4, Peg.Book, 0, "primer", "Учебник")
  Add(12, 4, Peg.Book, 0, "credits-small", "Титры")

  Add(16, 4, Peg.Page, #CustomMissions() == 0 and 14 or 0, "skip", "Выбор уровня")

  return { bg = {0.1, 0.04, 0.45} }
end

function wood()
  Add(8, 3, Peg.Level, 5, "missions/wood1", "Путешествие")
  Add(12, 3, Peg.Level, 6, "missions/wood2", "Сброс")
  Add(16, 3, Peg.Level, 7, "missions/wood3", "Жёрдочки")
  Add(6, 6, Peg.Level, 7, "missions/wood4", "Ловушка")
  Add(10, 6, Peg.Level, 8, "missions/wood5", "Безопасная")
  Add(14, 6, Peg.Level, 9, "missions/wood6", "Ямы")
  Add(4, 9, Peg.Level, 10, "missions/wood7", "Неловкость")
  Add(8, 9, Peg.Level, 11, "missions/wood8", "Ситуация")
  Add(12, 9, Peg.Level, 12, "missions/wood9", "Петля")
  Add(16, 9, Peg.Level, 13, "missions/wood10", "Узел")
  Add(6, 12, Peg.Page, 14, "sewer", "Канализация")
  Add(10, 12, Peg.Level, 15, "missions/wood11", "Перспектива")
  Add(14, 12, Peg.Level, 16, "missions/wood12", "Ещё безопаснее")

  Add(4, 3, Peg.Back)

  return { bg = {0.2, 0.4, 0.2} }
end

function sewer()
  Add(8, 6, Peg.Level, 14, "missions/sewer1", "Потоп")
  Add(12, 6, Peg.Level, 15, "missions/sewer2", "Водосток")
  Add(6, 9, Peg.Level, 16, "missions/sewer3", "Бассейн")
  Add(10, 9, Peg.Level, 17, "missions/sewer4", "Повтор")
  Add(14, 9, Peg.Level, 18, "missions/sewer5", "Замок")
  Add(4, 12, Peg.Level, 19, "missions/sewer6", "Водоворот")
  Add(8, 12, Peg.Page, 20, "castle", "Подземелье")
  Add(12, 12, Peg.Level, 21, "missions/sewer7", "Переставь")
  Add(16, 12, Peg.Level, 22, "missions/sewer8", "Проникни")

  Add(10, 3, Peg.Back)

  return { bg = {0.15, 0.35, 0.5} }
end

function castle()
  Add(6, 5.5, Peg.Level, 20, "missions/basement1", "Зелень")
  Add(9, 4.5, Peg.Level, 21, "missions/basement2", "Возми с собой")
  Add(12, 3.5, Peg.Level, 22, "missions/basement3", "Куча")
  Add(6, 9.5, Peg.Level, 23, "missions/basement4", "Дотянись")
  Add(9, 8.5, Peg.Level, 24, "missions/basement5", "Тюрьма")
  Add(12, 7.5, Peg.Level, 25, "missions/basement6", "Пусто")
  Add(15, 6.5, Peg.Level, 26, "missions/basement7", "Самая безопасная")
  Add(9, 12.5, Peg.Level, 27, "missions/basement8", "Шлюзы")
  Add(12, 11.5, Peg.Page, 28, "villa", "Руины")
  Add(15, 10.5, Peg.Level, 29, "missions/basement9", "Чердак")
  Add(18, 9.5, Peg.Level, 30, "missions/basement10", "Преграда")

  Add(3, 6.5, Peg.Back)

  return { bg = {0.3, 0.15, 0.25} }
end

function villa()
  Add(6, 3, Peg.Level, 28, "missions/garden1", "Провал")
  Add(9, 3, Peg.Level, 29, "missions/garden2", "Мост")
  Add(6, 6, Peg.Level, 30, "missions/garden3", "Кислота")
  Add(9, 6, Peg.Level, 31, "missions/garden4", "Блок")
  Add(12, 6, Peg.Level, 32, "missions/garden5", "Обратная связь")
  Add(9, 9, Peg.Level, 33, "missions/garden6", "Ванна")
  Add(12, 9, Peg.Level, 34, "missions/garden7", "Вставь")
  Add(15, 9, Peg.Level, 35, "missions/garden8", "Колонна")
  Add(12, 12, Peg.Page, 36, "temple", "Храм")
  Add(15, 12, Peg.Level, 37, "missions/garden9", "Непонятка")
  Add(18, 12, Peg.Level, 38, "missions/garden10", "Переплетение")

  Add(3, 3, Peg.Back)

  return { bg = {0.7, 0.65, 0.75} }
end

function temple()
  Add(10, 3, Peg.Level, 36, "missions/temple1", "Щель")
  Add(14, 3, Peg.Level, 37, "missions/temple2", "Продолжить")
  Add(4, 6, Peg.Level, 38, "missions/temple3", "Постоянство")
  Add(8, 6, Peg.Level, 39, "missions/temple4", "Перестройка")
  Add(12, 6, Peg.Level, 40, "missions/temple5", "Банка")
  Add(16, 6, Peg.Level, 41, "missions/temple6", "Построй-ка")
  Add(6, 9, Peg.Level, 42, "missions/temple7", "Внутри")
  Add(10, 9, Peg.Level, 43, "missions/temple8", "Вплетение")
  Add(14, 9, Peg.Level, 44, "missions/temple9", "Зажим")
  Add(4, 12, Peg.Level, 45, "missions/temple10", "Обход")
  Add(8, 12, Peg.Page, 48, "dark", "Пропасть")
  Add(12, 12, Peg.Level, 49, "missions/temple11", "Гидрофобия")
  Add(16, 12, Peg.Level, 50, "missions/temple12", "Мозоль")

  Add(6, 3, Peg.Back)

  return { bg = {0.65, 0.45, 0.1} }
end

function dark(complete)
  local x = 0.86602540378;
  Add(10, 3.5, Peg.Level, 48, "missions/dark1", "Захват")
  Add(10 + 4 * x, 5.5, Peg.Level, 50, "missions/dark2", "Путь-дорога")
  Add(10 + 4 * x, 9.5, Peg.Level, 52, "missions/dark3", "Грузоподъёмность")
  Add(10, 11.5, Peg.Level, 54, "missions/dark4", "Алтарь")
  Add(10 - 4 * x, 9.5, Peg.Level, 56, "missions/dark5", "Ещё хуже")
  Add(10 - 4 * x, 5.5, Peg.Level, 58, "missions/dark6", "Трилемма")

  if complete then
    Add(17.5, 7.5, Peg.Book, 0, "credits-full", "Конец!")
  end
  Add(10, 7.5, Peg.Back)

  return { bg = {0.1, 0.0, 0.1} }
end

function skip(complete)
  Add(10, 11, Peg.Back)
  Add(4, 10, Peg.Page, 5, "wood", "Лес")
  Add(5, 6.5, Peg.Page, 14, "sewer", "Канализация")
  Add(8, 4, Peg.Page, 20, "castle", "Подземелье")
  Add(12, 4, Peg.Page, 28, "villa", "Руины")
  Add(15, 6.5, Peg.Page, 36, "temple", "Храм")
  Add(16, 10, Peg.Page, 48, "dark", "Пропасть")

  Add(6, 13, Peg.Hub, 28, "dlc", "Загадка слизи")
  Add(14, 13, Peg.Hub, 28, "dlc2", "The Last Tapestry")

  if #CustomMissions() > 0 then
    Add(10, 7.5, Peg.Hub, 0, "custom", "Custom")
  end
  
  Add(17, 3, Peg.Hub, complete and 0 or 999, "TheIcePalace", "The Ice Palace")

  return { bg = {0.4, 0.0, 0.0} }
end

