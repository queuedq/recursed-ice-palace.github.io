Add-Type -AssemblyName System.Windows.Forms

Import-LocalizedData -BindingVariable msgs -FileName messages.psd1

$dlcName = "The Ice Palace v1.0"
$dlcFolderName = 'TheIcePalace'
$dlcLuaName = 'TheIcePalace.lua'
$dlcNexusInjection = '  Add(17, 3, Peg.Hub, complete and 0 or 999, "TheIcePalace", "The Ice Palace")'

$steamDirCandidates = @(
	"\Program Files\Steam", "\Program Files (x86)\Steam", "\Steam"
)

Write-Host -ForegroundColor Blue -BackgroundColor White ($msgs.promptTitle -f $dlcName)

function PrintError($text) {
	[Console]::ForegroundColor = 'Red'
	[Console]::Error.WriteLine($msgs.error -f $text)
	[Console]::ResetColor()
}

function PrintWarn($text) {
	[Console]::ForegroundColor = 'Yellow'
	[Console]::Error.WriteLine($msgs.warn -f $text)
	[Console]::ResetColor()
}

function PrintResultTxt($i) {
	switch($i) {
		0 {Write-Host $msgs.resultFail -ForegroundColor Red -BackgroundColor White}
		1 {Write-Host $msgs.resultOK -ForegroundColor DarkGreen}
		2 {Write-Host $msgs.resultAlready -ForegroundColor Yellow}
	}
}

function IsSteamDir($dir) {
	if(-not ([bool]$dir) -Or -not (Test-Path -PathType Container $dir)) {
		return $false
	}
	$steamEXE = Join-Path $dir "Steam.exe"
	$steamApps = Join-Path $dir "steamapps"
	$userData = Join-Path $dir "userdata"
	if(-not (Test-Path -PathType Leaf $steamEXE)){return $false}
	if(-not (Test-Path -PathType Container $steamApps)){return $false}
	if(-not (Test-Path -PathType Container $userData)){return $false}
	return $true
}

function IsRecursedDir($dir) {
	if ($dir -eq $null) {
		return $false
	}
	$recursedEXE = Join-Path $dir "Recursed.exe"
	$dataDirectory = Join-Path $dir "data"
	$dataInit = Join-Path $dataDirectory "init.lua"
	$dataNexus = Join-Path $dataDirectory "nexus.lua"
	if(-not (Test-Path -PathType Leaf $recursedEXE)){return $false}
	if(-not (Test-Path -PathType Container $dataDirectory)){return $false}
	if(-not (Test-Path -PathType Leaf $dataInit)){return $false}
	if(-not (Test-Path -PathType Leaf $dataNexus)){return $false}

	return $true
}

function InstallRecursed($recursedDir) {
	if(-not (IsRecursedDir $recursedDir)){
		return $false
	}
	$msgs.promptInstalling -f ($dlcName, $recursedDir) | Write-Host
	$someNotInstalled = $false
	$someInstalled = $false
	$noFailure = $true

	# Copy the DLC folder
	Write-Host $msgs.promptCopyingData "" -NoNewLine
	$dlcSource = Join-Path (Get-Location) $dlcFolderName
	$dlcDestination = Join-Path $recursedDir $dlcFolderName
	if(Test-Path -PathType Container $dlcDestination){
		$someInstalled = $true
		PrintResultTxt 2
	}else{
		$someNotInstalled = $true
		Copy-Item $dlcSource $dlcDestination -Recurse
		PrintResultTxt 1
	}

	# Copy the Lua file
	Write-Host $msgs.promptCopyingLua "" -NoNewLine
	$dataDir = Join-Path $recursedDir "data"
	$luaSource = Join-Path (Get-Location) $dlcLuaName
	$luaDestination = Join-Path $dataDir $dlcLuaName

	if(Test-Path -PathType Leaf $luaDestination){
		$someInstalled = $true
		PrintResultTxt 2
	}else{
		$someNotInstalled = $true
		Copy-Item $luaSource $luaDestination
		PrintResultTxt 1
	}

	# Inject the Nexus file
	$injectionFailed = $false
	$someAlreadyInjected = $false
	$someNotInjected = $false
	Write-Host $msgs.promptInjectingNexus "" -NoNewLine
	foreach($nexusPath in (Join-Path $dataDir "nexus*.lua" -Resolve)) {
		switch(InjectNexus $nexusPath){
			0 {
				$injectionFailed = $true
				$noFailure = $false
				break
			}
			1 {
				$someNotInjected = $true
				$someNotInstalled = $true
			}
			2 {
				$someAlreadyInjected = $true
				$someInstalled = $true
			}
		}
	}

	if($injectionFailed){
		PrintResultTxt 0
	}elseif($someAlreadyInjected){
		PrintResultTxt 2
	}else{
		PrintResultTxt 1
	}

	if($someInstalled){
		if($someNotInstalled){
			PrintWarn ($msgs.warnPartiallyInstalled -f $dlcName)
		}else{
			PrintWarn ($msgs.warnAlreadyInstalled -f $dlcName)
		}
	}

	return $noFailure
}

function InjectNexus($nexusPath) {
	$nexusContent = Get-Content -Encoding UTF8 $nexusPath
	$nexusNewContent = New-Object System.Collections.Generic.List[string]
	$numSkips = 0
	foreach($line in $nexusContent){
		if($line -eq "function skip(complete)"){
			return 2
		}
		if($line -eq "function skip()"){
			$numSkips += 1
			$nexusNewContent.Add('function skip(complete)')
			$nexusNewContent.Add($dlcNexusInjection)
			if($numSkips -ne 1){
				return 0
			}
		}else{
			$nexusNewContent.Add($line)
		}
	}
	$nexusNewContent | Set-Content -Encoding UTF8 $nexusPath
	return 1
}

function GetRecursedDirectoryFromSteam($steamDir) {
	if($steamDir -eq $null){return $null}

	return [io.path]::Combine($steamDir, "steamapps", "common", "Recursed")
}

function FindRecursedDirectory($dir) {
	if($dir -eq $null){return $null}

	if(IsSteamDir $dir){return GetRecursedDirectoryFromSteam $dir}
	if(IsRecursedDir $dir){return $dir}

	$parentDir = Split-Path -Parent $dir

	# Find the Steam directory from the given directory's parent or children
	$tmpPath = Join-Path $dir "Steam"
	if(IsSteamDir $tmpPath){return GetRecursedDirectoryFromSteam $tmpPath}
	if($parentDir -And (IsSteamDir $tmpPath)){return GetRecursedDirectoryFromSteam $parentDir}

	# Find the Recursed directory from the given directory's parent or children
	$tmpPath = Join-Path $dir "Recursed"
	if(IsRecursedDir $tmpPath){return $tmpPath}
	if($parentDir -And (IsRecursedDir $tmpPath)){return $parentDir}

	return $null
}

function GuessSteamDirectory() {
	foreach($drive in (Get-Volume)){
		$letter = $drive.DriveLetter
		if(-not ($letter)){continue}
		foreach($candi in $steamDirCandidates){
			$candiPath = "${letter}:${candi}"
			if(IsSteamDir $candiPath){
				return $candiPath
			}
		}
	}
	return $null
}

function GetSteamDirectory($initialPath) {
	$f = New-Object Windows.Forms.FolderBrowserDialog
	if($initialPath){
		$f.Description = "{0}`n{1}" -f ($msgs.promptSelectSteamDirWithDefault, $msgs.promptSelectSteamDirExample)
	}else{
		$f.Description = "{0}`n{1}" -f ($msgs.promptSelectSteamDir, $msgs.promptSelectSteamDirExample)
	}
	$f.SelectedPath = $initialPath

	$result = $f.ShowDialog()

	if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
		return $f.SelectedPath
	}
	return $null
}

try{
	$steamDir = GetSteamDirectory(GuessSteamDirectory)
	$recursedDir = FindRecursedDirectory $steamDir

	if (-not(IsRecursedDir $recursedDir)) {
		if(IsSteamDir $steamDir){
			PrintError $msgs.errorNoRecursed
		}else{
			PrintError $msgs.errorNotSteam
		}
	} else {
		$result = InstallRecursed $recursedDir
		if($result -eq $true){
			Write-Host -ForegroundColor DarkGreen -BackgroundColor White $msgs.okInstall
		}else{
			PrintError $msgs.errorInstallFailed
		}
	}
}catch{
	Write-Error $_.Exception
}finally{
	Pause
}
